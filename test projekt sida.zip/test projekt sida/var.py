a = 0
b = 0
y = 0

timer1 = True

t1 = 0
t2 = 0
t3 = 0