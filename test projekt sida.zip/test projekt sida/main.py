import test
import var

test.app.run()

